import React, { useState , useEffect} from 'react';
import { useTheme } from '../context/ThemeContext';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import logo from "../assets/flix-logo.png";

const Header = ({onSearch,showSearch}) => {
    const [searchTerm, setSearchTerm] = useState('');
    const { theme, toggleTheme } = useTheme();
    const { t, i18n } = useTranslation();
    const navigate = useNavigate();
    const handleInputChange = (e) => {
        setSearchTerm(e.target.value);
    };
    useEffect(() => {
        // Change the direction based on selected language
        const dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
        document.documentElement.setAttribute('dir', dir); // Set direction globally
        console.log(document.documentElement.getAttribute('dir')); // Debug the direction
    }, [i18n.language]);

    const handleSearch = () => {
        if (searchTerm.trim()) {
            onSearch(searchTerm);
        }
    };

    const handleLanguageChange = (lang) => {
        i18n.changeLanguage(lang); // Change the language manually
    };

    const goToHomePage = (lang) => {
        navigate(`/`);
    };

    return (
        <header className={`header ${theme}`}>
            <div className="container">
                <img src={logo} style={{width: "15%",height: "50px",cursor:"pointer"}} onClick={goToHomePage}/>
                { showSearch && <div className="search-container">
                    <input
                        type="text"
                        placeholder={t('searchPlaceholder')}
                        value={searchTerm}
                        onChange={handleInputChange}
                        className="input"
                    />
                    <button onClick={handleSearch} className="button">{t('search')}</button>
                </div> }

                <div className="right-container">
                    <button onClick={toggleTheme} className={theme === 'dark' ? "theme-button-light" : "theme-button-dark"}>
                        {theme === 'dark' ? t('lightTheme') : t('darkTheme')}<i class={theme === 'dark' ? "fa fa-sun-o" : "fa fa-moon-o"}></i>
                    </button>
                    <div className="language-container">
                        <button onClick={() => handleLanguageChange('en')} className="language-button">EN</button>
                        <button onClick={() => handleLanguageChange('ar')} className="language-button">AR</button>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
