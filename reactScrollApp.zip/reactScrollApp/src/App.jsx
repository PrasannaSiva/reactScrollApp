import React,{useState} from 'react'
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Header from './components/Header.jsx';
import Products from './components/Products.jsx';
import MovieDetails from './components/MovieDetails.jsx';
function App() {
const [searchTerm,setSearchTerm] = useState("");

function handleSearch(searchtext){
   setSearchTerm(searchtext);
}
  return (
    <Router>
      <Routes>
        <Route path="/" element={
          <div>
            <Header onSearch={handleSearch} showSearch/>
            <Products searchTerm={searchTerm}/>
          </div>
        } />
        <Route path="/movie/:id" element={
          <MovieDetails />
        } />
      </Routes>
    </Router>
  );
}

export default App
