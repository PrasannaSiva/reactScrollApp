import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

i18n.use(initReactI18next).init({
  resources: {
    en: {
      translation: {
        pageTitle: "Movie Search",
        search: "SEARCH",
        searchPlaceholder: "Search for movies or TV shows",
        lightTheme: "LIGHT MODE  ",
        darkTheme: "DARK MODE  ",
      },
    },
    ar: {
      translation: {
        pageTitle: "بحث الفيلم",
        search: "يبحث",
        searchPlaceholder: "ابحث عن الأفلام أو البرامج التلفزيونية",
        lightTheme: "ضوء",
        darkTheme: "مظلم",
      },
    },
  },
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false, 
  },
  react: {
    useSuspense: false,
  },
});

export default i18n;
