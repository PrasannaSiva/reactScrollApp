import React, { useState, useEffect } from 'react';
import { useParams, Link } from "react-router-dom";
import { API_KEY } from '../api/APIkey';
import './MovieDetails.css'; // Import the styles for the page
import Header from "./Header";

const MovieDetails = () => {
    const { id } = useParams();  // Get the product id from the URL
    const [movie, setMovie] = useState(null);

    useEffect(() => {
        // Fetch the product data by ID
        const fetchMovieDetails = async () => {
            const response = await fetch(`https://www.omdbapi.com/?i=${id}&plot=full&apikey=${API_KEY}`);
            try {
                const data = await response.json();
                setMovie(data);
            } catch (e) {
                console.log("Error:" + e);
            }
        };

        fetchMovieDetails();
    }, [id]);

    if (!movie) {
        return <div>Loading...</div>;  // Show loading until product data is fetched
    }

    return (
        <div className="movie-details">
            <Header />
            <div className="movie-details__poster">
                <img src={movie.Poster} alt={movie.Title} />
            </div>
            <div className="movie-details__info">
                <h1 className="movie-details__title">{movie.Title}</h1>
                <p className="movie-details__year">Year: {movie.Year}</p>
                <p className="movie-details__rated">Rated: {movie.Rated}</p>
                <p className="movie-details__released">Released: {movie.Released}</p>
                <p className="movie-details__runtime">Runtime: {movie.Runtime}</p>
                <p className="movie-details__genre">Genre: {movie.Genre}</p>
                <p className="movie-details__director">Director: {movie.Director}</p>
                <p className="movie-details__writer">Writer: {movie.Writer}</p>
                <p className="movie-details__actors">Actors: {movie.Actors}</p>
                <p className="movie-details__plot">Plot: {movie.Plot}</p>
                <p className="movie-details__language">Language: {movie.Language}</p>
                <p className="movie-details__country">Country: {movie.Country}</p>
                <p className="movie-details__awards">Awards: {movie.Awards}</p>

                {/* Ratings */}
                <div className="movie-details__ratings">
                    <h3>Ratings:</h3>
                    {movie.Ratings.map((rating, index) => (
                        <p key={index}>
                            {rating.Source}: {rating.Value}
                        </p>
                    ))}
                </div>

                {/* IMDb Link */}
                <p className="movie-details__imdb">
                    <a
                        href={`https://www.imdb.com/title/${movie.imdbID}`}
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        More Info on IMDb
                    </a>
                </p>
            </div>
        </div>
    );
};

export default MovieDetails;
