import React from 'react';
import { useNavigate } from 'react-router-dom';
import './MovieCard.css'; 

const MovieCard = ({ movie ,index}) => {
    const navigate = useNavigate();

    const handleCardClick = () => {
        // Navigate to the movie details page using the imdbID
        navigate(`/movie/${movie.imdbID}`);
    };
    return (
        <div className="movie-card" onClick={handleCardClick}>
            <img
                src={movie.Poster}
                alt={movie.Title}
                className="movie-card__poster"
                loading="lazy"
            />
            <div className="movie-card__details">
                <h2 className="movie-card__title">{index+". "+movie.Title}</h2>
                <div className="movie-card__hover-info">
                    <p className="movie-card__type">Type: {movie.Type}</p>
                    <p className="movie-card__year">Year: {movie.Year}</p>
                </div>
            </div>
        </div>
    );
};

export default MovieCard;
