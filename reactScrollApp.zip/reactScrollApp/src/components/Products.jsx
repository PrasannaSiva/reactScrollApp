import { useEffect, useState, useRef, useCallback } from "react";
import { API_KEY } from "../api/APIkey.jsx";
import MovieCard from "./MovieCard.jsx";

export default function Products({ searchTerm }) {
  const [loadedProducts, setLoadedProducts] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false); // Track loading state
  const loader = useRef(null);
  async function fetchProducts(page) {
    if (loading) return;
    setLoading(true);
      const response = await fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&s=${searchTerm || '*ave*'}&page=${page}`);
      const fetchedProducts = await response.json();
      setLoadedProducts(prevItems => {
        return [...prevItems, ...fetchedProducts.Search];
      });
      setLoading(false);
  }
  useEffect(() => {
    setLoadedProducts([]); // Clear current results
    setPage(1); // Reset page to 1
    fetchProducts(1, searchTerm);
  }, [searchTerm]);
  const handleObserver = useCallback((entries) => {
    const target = entries[0];
    if (target.isIntersecting && !loading) {
      setPage((prevPage) => {
        const nextPage = prevPage + 1;
        fetchProducts(nextPage);
        return nextPage;
      });
    }
  }, [loading]);
  useEffect(() => {
    const option = {
      root: null,
      rootMargin: "100px",
      threshold: 0.25
    };
    const observer = new IntersectionObserver(handleObserver, option);
    if (loader.current) observer.observe(loader.current);
    return () => {
      if (loader.current) observer.unobserve(loader.current);
    };
  }, [handleObserver]);
  return (
    <><ul id='product'>{loadedProducts.map(
      (item, idx) => <MovieCard key={idx} movie={item} index={idx}></MovieCard> 
    )}</ul>
      {loading && <div className="loading-spinner">Loading...</div>} {/* Loading indicator */}
      <div ref={loader} id='intersection'></div>
    </>);
}
